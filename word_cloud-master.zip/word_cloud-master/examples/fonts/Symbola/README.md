The symbola font was downloaded from George Douros at http://users.teilar.gr/~g1951d/

On that site (and inside the pdf), the license is described as follows:
In lieu of a licence; fonts and documents in this site are free for any use; George Douros